document.addEventListener("DOMContentLoaded", function() {
const form = document.getElementById("formular-comentariu");
const listaComentarii = document.getElementById("lista-comentarii");


form.addEventListener("submit", function(e) {
    e.preventDefault();
    const comentariu = document.getElementById("comentariu").value;

    fetch("contact", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `comentariu=${encodeURIComponent(comentariu)}&action=add`
    })
      .then(() => {
        form.reset();  
        
      })
      .catch(error => console.error("Eroare la trimiterea comentariului:", error));
});

document.getElementById("sterge-comentariu").addEventListener("click", function () {
    if (confirm("Sigur vrei să ștergi ultimul comentariu?")) {

      fetch("contact", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "action=delete_last"
      })
        
        .catch(error => console.error("Eroare la ștergerea comentariului:", error));
    }
  });


});
