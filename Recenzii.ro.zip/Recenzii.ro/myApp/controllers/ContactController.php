<?php

class ContactController extends AppController
{
    public function __construct()
    {
        $this->init();
    }

    public function init()
    {
        $dbModel = new DBModel();
        $conn = $dbModel->db();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comentariu'])) {
            $comentariu = $conn->real_escape_string($_POST['comentariu']);
            $conn->query("INSERT INTO comentarii (text) VALUES ('$comentariu')");
            header('Location: contact');
            exit();
        }

        if (isset($_POST['delete_last'])) {
            $conn->query("DELETE FROM comentarii ORDER BY id DESC LIMIT 1");
            header('Location: contact');
            exit();
        }

        
        $comentarii = [];
        $result = $conn->query("SELECT * FROM comentarii ORDER BY id DESC");

        while ($row = $result->fetch_assoc()) {
            $comentarii[] = $row['text'];  
        }

       
        $separator = "<p>";
        $string = implode($separator, $comentarii);
        $data['mainContent'] =$string;

        
        echo $this->render(APP_PATH . VIEWS . 'contact.html', $data);
        exit();
    }
}
?>
