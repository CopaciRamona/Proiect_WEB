<?php

class A2Controller extends AppController
{
    public function __construct(){
        $this->init();
    }

    public function init(){
        echo $this->render(APP_PATH.VIEWS.'recenzie2.html');
        }        
 }