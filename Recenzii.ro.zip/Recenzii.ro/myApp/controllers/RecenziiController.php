<?php

class RecenziiController extends AppController
{
    public function __construct(){
        $this->init();
    }

    public function init(){
        echo $this->render(APP_PATH.VIEWS.'recenzii.html');
        }        
 }