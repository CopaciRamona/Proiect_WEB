<?php

class AbonareController extends AppController
{
    public function __construct() {
        $this->init();
    }

    public function init() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
            $conn = (new DBModel())->db();
            $email = $conn->real_escape_string($_POST['email']);
            $conn->query("INSERT INTO abonati (email) VALUES ('$email')");
            $conn->close();
        }

        header('Location: index.php?page=home');
        exit;
    }
}
